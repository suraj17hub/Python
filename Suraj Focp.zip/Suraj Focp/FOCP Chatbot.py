import random
import time
import json
import re

def load_responses():
  """Loads responses from a JSON file."""
  try:
    with open("university_fees_responses.json", "r") as f:
      return json.load(f)
  except FileNotFoundError:
    print("Warning: university_fees_responses.json not found. Using default responses.")
    return {
        "fees": "Tuition fees vary by program and year. You can find detailed fee structures on our website.",
        "scholarships": "We offer various scholarships for eligible students. Visit our scholarships page for details and application deadlines.",
        "admission": "The admission process generally includes:\n"
                     "1. Online Application: Submit the application form with necessary documents.\n"
                     "2. Interview (if applicable): Some programs may require an interview.\n"
                     "3. Offer Letter: If selected, you will receive an offer letter with admission instructions.\n"
                     "For detailed information, please visit our website.",
        "activity": "Upcoming activity related to admissions and scholarships will be posted on our university activity calendar.",
        "contact": "You can contact us via phone at +977-1-3544000 or email at It@poppl.edu.np",
        "about": "The University of Poppleton stands as a premier higher education institution in the UK, dedicated to delivering top-notch education through a diverse selection of undergraduate and postgraduate programs. Our mission is to ensure quality learning experiences that emphasize practical skills and industry relevance. For more information, visit our website..",
        "location": "University of Poppleton has located in UK, York."
    }

def get_agent_name():
  """Generates a random agent name."""
  agents =["ChatBot", "Advisor", "Guide", "UniBot"]
  return random.choice(agents)

def get_random_response():
  """Generates a random generic response."""
  responses = [
      "I'm here to help you with your university inquiries.",
  ]
  return random.choice(responses)

def get_specific_response(user_input, responses):
  """Tries to find a specific response based on keywords."""
  for keyword, response in responses.items():
    if keyword in user_input:
      return response

  # Check for partial matches using regular expressions
  for keyword, response in responses.items():
    if re.search(r"\b" + keyword + r"\b", user_input):
      return response

  return None

def log_chat(user_input, bot_response, log_file="chat_log.txt"):
  """Logs the chat interaction to a file."""
  with open(log_file, "a") as f:
    f.write(f"User: {user_input}\n")
    f.write(f"Bot: {bot_response}\n\n")

def main():
  """Main function for the chatbot interaction."""
  agent_name = get_agent_name()
  responses = load_responses()

  print(f"Hello! I'm {agent_name}, your university admissions and fee assistant.")
  print("What's your name?")
  user_name = input()
  print(f"Hello, {user_name}! Welcome to University of Poppleton. How can I help you today?")

  while True:
    user_input = input().lower()

    if user_input in ["bye", "quit", "exit"]:
      print("Goodbye, Have a nice day.")
      break

    specific_response = get_specific_response(user_input, responses)
    if specific_response:
      bot_response = specific_response
    else:
      bot_response = get_random_response()

    print(bot_response)
    log_chat(user_input, bot_response)

    # Simulate random disconnection (optional)
    if random.randint(1, 100) == 1:
      print("Connection lost. Reconnecting...")
      time.sleep(2)

if __name__ == "__main__":
  main()