if __name__ == "__main__":
    name = input("Enter your name: ").strip()
    formatted_name = name.capital()
    print(f"Hello, {formatted_name}!")