import random
import string

# 1. Convert a positive integer to binary (using built-in functionality)
def convert_to_binary(num):
    """Converts a positive integer to binary representation."""
    if num > 0:
        return bin(num)[2:]
    else:
        return "Please provide a positive whole number."

# 2. Find factors of a positive number
def get_divisors(num):
    """Returns a list of divisors of the given number."""
    if num <= 0:
        return "Please enter a positive integer."
    return [i for i in range(1, num + 1) if num % i == 0]

# 3. Check if a number is prime
def is_prime_number(value):
    """Checks if the given value is a prime number."""
    if value <= 1:
        return False
    for i in range(2, int(value ** 0.5) + 1):
        if value % i == 0:
            return False
    return True

# 4. Simple encryption: remove spaces and reverse the string
def reverse_encrypt(input_string):
    """Encrypts the given text by removing spaces and reversing it."""
    return input_string.replace(" ", "")[::-1]

# 5. Encrypt with random spacing
def encrypt_with_random_spacing(input_string):
    """Encrypts the given text by inserting it into random characters at a random interval."""
    spacing = random.randint(2, 20)
    random_characters = ''.join(random.choices(string.ascii_lowercase, k=len(input_string) * spacing))
    encrypted_string = ''.join([random_characters[i * spacing:(i * spacing) + spacing - 1] + char for i, char in enumerate(input_string)])
    return encrypted_string + random_characters[len(encrypted_string):], spacing

# 6. Decrypt a spaced message given the interval
def decrypt_random_spacing(encrypted_string, spacing):
    """Decrypts a message with random spacing using the provided interval."""
    return encrypted_string[spacing - 1::spacing]

# Testing the functions
if __name__ == "__main__":
    # Binary conversion
    print("Binary of 10:", convert_to_binary(10))

    # Factors (divisors)
    print("Divisors of 12:", get_divisors(12))

    # Prime check
    print("Is 13 prime?:", is_prime_number(13))

    # Simple encryption
    input_message = "hello world"
    print("Simple encryption:", reverse_encrypt(input_message))

    # Random spacing encryption
    encrypted_message, spacing = encrypt_with_random_spacing(input_message)
    print(f"Encrypted with random spacing: {encrypted_message}, Spacing: {spacing:.2f}")

    # Decrypting spaced message
    decrypted_message = decrypt_random_spacing(encrypted_message, spacing)
    print("Decrypted message:", decrypted_message)
