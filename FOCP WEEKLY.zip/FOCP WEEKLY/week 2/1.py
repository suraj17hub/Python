print("Hey! What's your name?")
user = input("Please enter your name: ")
print(f"Hey, {user}! Nice to meet you!")




