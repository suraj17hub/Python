total_sweets = int(input("Enter the total number of sweets: "))
num_students = int(input("Enter the number of students: "))

if num_students > 0:
    sweets_per_student = total_sweets // num_students
    leftover_sweets = total_sweets % num_students

    print(f"Each student gets {sweets_per_student} sweet(s).")
    print(f"The teacher will have {leftover_sweets} sweet(s) leftover.")

else:
    print("No students are present today. The teacher keeps all the sweets.")
