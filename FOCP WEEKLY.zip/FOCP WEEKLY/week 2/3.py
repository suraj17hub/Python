total_students = int(input("Enter the number of students: "))
group_capacity = int(input("Enter the required group size: "))
full_groups = total_students // group_capacity
remaining_students = total_students % group_capacity

print(f"There will be {full_groups} full groups, with {remaining_students} student(s) remaining.")




