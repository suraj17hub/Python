# interval_encryption.py
import random
import string

def encrypt_at_interval(input_data):
    space = random.randint(2, 20)
    encrypted_output = ""
    random_chars = lambda: random.choice(string.ascii_lowercase)
    for char in input_data:
        encrypted_output += char + "".join(random_chars() for _ in range(space - 1))
    return encrypted_output, space

# Test encrypt_at_interval
if __name__ == "__main__":
    original_message = input("Enter a message: ").replace(" ", "")
    encrypted_output, space = encrypt_at_interval(original_message)
    print(f"Encrypted message: {encrypted_output}")
    print(f"Interval: {space}")
