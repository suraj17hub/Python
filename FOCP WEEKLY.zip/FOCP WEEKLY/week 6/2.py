# integer_factors
def calculate_factors(num_value):
    return [i for i in range(1, num_value + 1) if num_value % i == 0]

# Test calculate_factors
if __name__ == "__main__":
    user_input = int(input("Enter an integer: "))
    print(f"Factors: {calculate_factors(user_input)}")


