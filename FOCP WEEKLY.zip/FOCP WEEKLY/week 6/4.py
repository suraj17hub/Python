# simple_encryption.py
def process_text(input_string):
    return input_string.replace(" ", "")[::-1]

# Test process_text
if __name__ == "__main__":
    user_message = input("Enter a message: ")
    print(f"Encrypted message: {process_text(user_message)}")
