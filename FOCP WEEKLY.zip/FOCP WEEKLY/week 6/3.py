# prime_check.py
def determine_prime(test_value):
    if test_value <= 1:
        return False
    for i in range(2, int(test_value**0.5) + 1):
        if test_value % i == 0:
            return False
    return True

# Test determine_prime
if __name__ == "__main__":
    input_value = int(input("Enter an integer: "))
    print(f"Is prime: {determine_prime(input_value)}")

