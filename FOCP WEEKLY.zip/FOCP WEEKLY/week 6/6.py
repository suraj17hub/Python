# interval_decryption.py
def extract_at_interval(encrypted_data, step):
    return encrypted_data[::step]

# Test extract_at_interval
if __name__ == "__main__":
    encrypted_data = input("Enter the encrypted message: ")
    step = int(input("Enter the interval: "))
    print(f"Decrypted message: {extract_at_interval(encrypted_data, step)}")
