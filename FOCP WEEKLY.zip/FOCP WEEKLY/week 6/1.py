# binary_representation.py
def convert_to_binary(num_value):
    return bin(num_value)[2:]

# Test convert_to_binary
if __name__ == "__main__":
    input_value = int(input("Please enter a positive integer: "))
    print(f"Binary form: {convert_to_binary(input_value)}")

