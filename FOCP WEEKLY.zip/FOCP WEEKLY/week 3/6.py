i = 1
while i <= 12:
    result = i * 7
    print(f"{i} x 7 = {result}")
    i += 1
