COMMON_PASSWORDS = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']

new_password = input("Enter a new password (8-12 characters): ")

if len(new_password) < 8 or len(new_password) > 12:
    print("Error: Password must be between 8 and 12 characters.")
elif new_password.lower() in COMMON_PASSWORDS:
    print("Password is too common. Please choose a more secure password.")
else:
    confirm_password = input("Re-enter your password: ")
    if new_password == confirm_password:
        print("Password successfully set!")
    else:
        print("Error: Passwords do not match. Please try again.")