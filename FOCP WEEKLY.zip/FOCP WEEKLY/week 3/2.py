new_password = input("Enter a new password: ")
confirm_password = input("Re-enter your password: ")

if new_password == confirm_password:
    print("Password successfully set!")
else:
    print("Error! Passwords do not match. Please try again.")
